//Header to define the first exercice
#pragma once
void exercice1();