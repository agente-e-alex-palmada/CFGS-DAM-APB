//Header to define the selection that will show on screen
#pragma once
void selection();