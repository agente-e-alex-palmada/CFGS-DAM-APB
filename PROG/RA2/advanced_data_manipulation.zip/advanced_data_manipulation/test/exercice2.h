//Header to define the second exercice
#pragma once
void exercice2();