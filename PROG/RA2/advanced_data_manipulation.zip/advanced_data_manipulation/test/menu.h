//Header to define the menu
#pragma once
void menu();