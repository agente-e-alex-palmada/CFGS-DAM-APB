//Including libraries
#include <iostream>
#include "menu.h"

/// <summary>
/// Calling the function menu in the main, this is another file
/// </summary>
void main() {
    menu();
}
