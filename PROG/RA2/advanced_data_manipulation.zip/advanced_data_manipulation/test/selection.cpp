#include <iostream>
using namespace std;

/// <summary>
/// This function only displays what options has the user, if he writes 1, he weill go to exercice 1
/// </summary>
void selection() {
    cout << "\n1. Exercice 1: Fractiorial fraction";
    cout << "\n2. Exercice 2: First number";
    cout << "\n3. Exit";
    cout << "\n\nEnter number: ";
}